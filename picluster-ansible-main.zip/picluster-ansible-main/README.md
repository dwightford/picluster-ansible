# picluster-ansible
This repository contains the Ansible Playbooks used for my <a href="https://www.dinofizzotti.com/blog/2020-04-10-raspberry-pi-cluster-part-1-provisioning-with-ansible-and-temperature-monitoring-using-prometheus-and-grafana/">Pi Cluster project</a>.
